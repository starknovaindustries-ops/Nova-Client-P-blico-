plugins {
    id("java-library")
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.compilerArgs.add("-parameters")
}

dependencies {
    compileOnly("org.projectlombok:lombok:1.18.34")
    annotationProcessor("org.projectlombok:lombok:1.18.34")
    compileOnly("org.checkerframework:checker-qual:3.37.0")

    api(platform(libs.fastutil.bom))
    api(libs.netty.buffer)
    api(libs.fastutil.long.common)
    api(libs.fastutil.long.obj.maps)
    api(libs.fastutil.int.obj.maps)
    api(libs.fastutil.obj.int.maps)
    api(libs.math)
    api(libs.jose4j)
    api(libs.nbt)
    api(libs.jackson.annotations)
    api(libs.jackson.databind)
    api("org.slf4j:slf4j-api:2.0.16")
}
