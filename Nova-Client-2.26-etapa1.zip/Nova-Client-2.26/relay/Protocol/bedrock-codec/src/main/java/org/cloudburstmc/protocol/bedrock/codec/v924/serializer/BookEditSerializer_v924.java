package org.cloudburstmc.protocol.bedrock.codec.v924.serializer;

import io.netty.buffer.ByteBuf;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.v291.serializer.BookEditSerializer_v291;
import org.cloudburstmc.protocol.bedrock.packet.BookEditPacket;
import org.cloudburstmc.protocol.bedrock.util.VarInts;

public class BookEditSerializer_v924 extends BookEditSerializer_v291 {

    public static final BookEditSerializer_v924 INSTANCE = new BookEditSerializer_v924();

    @Override
    public void serialize(ByteBuf buffer, BedrockCodecHelper helper, BookEditPacket packet) {
        VarInts.writeInt(buffer, packet.getInventorySlot());
        VarInts.writeUnsignedInt(buffer, packet.getAction().ordinal());

        switch (packet.getAction()) {
            case REPLACE_PAGE:
            case ADD_PAGE:
                VarInts.writeInt(buffer, packet.getPageNumber());
                helper.writeString(buffer, packet.getText());
                helper.writeString(buffer, packet.getPhotoName());
                break;
            case DELETE_PAGE:
                VarInts.writeInt(buffer, packet.getPageNumber());
                break;
            case SWAP_PAGES:
                VarInts.writeInt(buffer, packet.getPageNumber());
                VarInts.writeInt(buffer, packet.getSecondaryPageNumber());
                break;
            case SIGN_BOOK:
                helper.writeString(buffer, packet.getTitle());
                helper.writeString(buffer, packet.getAuthor());
                helper.writeString(buffer, packet.getXuid());
                break;
        }
    }

    @Override
    public void deserialize(ByteBuf buffer, BedrockCodecHelper helper, BookEditPacket packet) {
        packet.setInventorySlot(VarInts.readInt(buffer));
        packet.setAction(types.get(VarInts.readUnsignedInt(buffer)));

        switch (packet.getAction()) {
            case REPLACE_PAGE:
            case ADD_PAGE:
                packet.setPageNumber(VarInts.readInt(buffer));
                packet.setText(helper.readString(buffer));
                packet.setPhotoName(helper.readString(buffer));
                break;
            case DELETE_PAGE:
                packet.setPageNumber(VarInts.readInt(buffer));
                break;
            case SWAP_PAGES:
                packet.setPageNumber(VarInts.readInt(buffer));
                packet.setSecondaryPageNumber(VarInts.readInt(buffer));
                break;
            case SIGN_BOOK:
                packet.setTitle(helper.readString(buffer));
                packet.setAuthor(helper.readString(buffer));
                packet.setXuid(helper.readString(buffer));
                break;
        }
    }
}
